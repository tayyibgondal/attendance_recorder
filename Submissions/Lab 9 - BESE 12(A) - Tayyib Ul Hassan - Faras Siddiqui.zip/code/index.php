<?php
// To create database and add data for the first time.
// include('database_creator.php');
